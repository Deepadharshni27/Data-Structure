import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the value of n:");
        int n = s.nextInt();
        int[] arr = new int[10];
        System.out.println("Enter array elemants:");
        for (int i = 0; i<n ; i++){
            arr[i] = s.nextInt();
        }
        System.out.println("Display array elements:");
        for (int i = 0; i<n ; i++){
            System.out.print(arr[i] + " ");
        }
        if (n < 10){
            System.out.print("\nEnter the element to be added at the end:");
            int newelement = s.nextInt();
            arr[n] = newelement;
            n++;
        }else{
            System.out.println("Array is already filled.");
        }
        System.out.println("Updated array:");
        for (int i = 0; i<n ; i++){
            System.out.print(arr[i]+" ");
        }
        
    }
}