import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the value of n:");
		int n = s.nextInt();
		int[] arr = new int[10];
		System.out.print("\nEnter the element for array :");
		for (int i = 0; i<n ; i++){
		    arr[i] = s.nextInt();
		}
		System.out.print("\nArray elements:");
		for (int i = 0; i<n ; i++){
		    System.out.print(arr[i]+" ");
		}
		if(n < 10){
		    System.out.print("\nEnter the element to be added in begining:");
		    int newelement = s.nextInt();
		    System.out.print("Enter the position (0 to " + n + "): ");
            int position = s.nextInt();
            if (position < 0 || position > n) {
                System.out.println("Invalid position! Must be between 0 and " + n);
            } else {
                for (int i = n; i > position; i--) {
                    arr[i] = arr[i - 1];
                }
                arr[position] = newelement;
                n++;
            }
        } else {
            System.out.println("Array is already full. Cannot insert more elements.");
        }
		System.out.println("Updated Array elements:");
		for (int i = 0; i<n ; i++){
		    System.out.print(arr[i]+" ");
		}
	}
}
